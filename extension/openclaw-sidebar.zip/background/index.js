"use strict";
/**
 * OpenClaw Sidebar - Service Worker
 *
 * Manages the WebSocket connection between the Extension and Relay Server.
 * The Relay Server handles Gateway authentication (device token).
 * Extension connects directly to Relay at wss://47.89.181.91:18790
 *
 * Architecture:
 *   Side Panel <---> Service Worker <---> Relay Server <---> Gateway
 */
const RELAY_URL = 'ws://47.89.181.91:18791';
const RECONNECT_DELAY_BASE = 1000;
const RECONNECT_DELAY_MAX = 30000;
const logger = {
    info: (msg, ...args) => console.log(`[SW] ${msg}`, ...args),
    warn: (msg, ...args) => console.warn(`[SW] ${msg}`, ...args),
    error: (msg, ...args) => console.error(`[SW] ${msg}`, ...args),
};
// ============================================================================
// State
// ============================================================================
let ws = null;
let connectionState = 'disconnected';
let reconnectAttempt = 0;
let activeSessionId = null;
// Pending requests for RPC call/response correlation
const pendingRequests = new Map();
// Port to side panel for event forwarding
let sidePanelPort = null;
// Queue events when side panel is not connected
const eventQueue = [];
function flushEventQueue() {
    while (eventQueue.length > 0 && sidePanelPort) {
        const { event, payload } = eventQueue.shift();
        sidePanelPort.postMessage({ type: 'event', event, payload });
    }
}
// ============================================================================
// Service Worker Lifecycle
// ============================================================================
chrome.runtime.onInstalled.addListener(() => {
    logger.info('Service Worker installed');
});
chrome.runtime.onConnect.addListener((port) => {
    if (port.name === 'openclaw-sidebar') {
        sidePanelPort = port;
        port.onDisconnect.addListener(() => {
            sidePanelPort = null;
        });
        // Send current connection state to newly connected panel
        port.postMessage({ type: 'connection-state', state: connectionState });
        // Flush any queued events
        flushEventQueue();
    }
});
// ============================================================================
// WebSocket Connection Management
// ============================================================================
function connect() {
    if (ws && (ws.readyState === WebSocket.OPEN || ws.readyState === WebSocket.CONNECTING)) {
        return;
    }
    connectionState = 'connecting';
    broadcastConnectionState();
    logger.info('Connecting to Relay...');
    ws = new WebSocket(RELAY_URL);
    ws.onopen = () => {
        logger.info('WebSocket connected to Relay');
        connectionState = 'connected';
        reconnectAttempt = 0;
        broadcastConnectionState();
    };
    ws.onmessage = (event) => {
        try {
            const frame = JSON.parse(event.data);
            handleFrame(frame);
        }
        catch (err) {
            logger.error('Failed to parse message', err);
        }
    };
    ws.onclose = () => {
        logger.warn('WebSocket disconnected');
        ws = null;
        connectionState = 'reconnecting';
        broadcastConnectionState();
        scheduleReconnect();
    };
    ws.onerror = () => {
        logger.error('WebSocket error');
    };
}
function scheduleReconnect() {
    const delay = Math.min(RECONNECT_DELAY_BASE * Math.pow(2, reconnectAttempt), RECONNECT_DELAY_MAX);
    reconnectAttempt++;
    logger.info(`Scheduling reconnect in ${delay}ms (attempt ${reconnectAttempt})`);
    setTimeout(connect, delay);
}
function disconnect() {
    connectionState = 'disconnected';
    broadcastConnectionState();
    if (ws) {
        ws.close();
        ws = null;
    }
}
function broadcastConnectionState() {
    if (sidePanelPort) {
        sidePanelPort.postMessage({ type: 'connection-state', state: connectionState });
        // Try to flush queued events when state changes
        flushEventQueue();
    }
}
function sendToRelay(frame) {
    if (!ws || ws.readyState !== WebSocket.OPEN) {
        logger.warn('WS not connected, dropping message');
        return false;
    }
    ws.send(JSON.stringify(frame));
    return true;
}
function handleFrame(frame) {
    switch (frame.type) {
        case 'event':
            handleEvent(frame);
            break;
        case 'res':
            handleResponse(frame);
            break;
        default:
            logger.warn('Unknown frame type', frame.type);
    }
}
function handleEvent(frame) {
    if (sidePanelPort) {
        sidePanelPort.postMessage({ type: 'event', event: frame.event, payload: frame.payload });
    }
    else {
        eventQueue.push({ event: frame.event, payload: frame.payload });
    }
}
function handleResponse(frame) {
    const pending = pendingRequests.get(frame.id);
    if (pending) {
        pendingRequests.delete(frame.id);
        if (frame.ok) {
            pending.resolve(frame.payload);
        }
        else {
            pending.reject(new Error(frame.error?.message || 'Request failed'));
        }
    }
}
// ============================================================================
// Message Routing (from Side Panel to Relay)
// ============================================================================
chrome.runtime.onMessage.addListener((message, _port, sendResponse) => {
    switch (message.type) {
        case 'req': {
            const id = crypto.randomUUID();
            const frame = {
                type: 'req',
                id,
                method: message.method,
                params: message.params,
            };
            if (!sendToRelay(frame)) {
                sendResponse({ ok: false, error: { code: 'NOT_CONNECTED', message: 'Not connected to Relay' } });
                return true;
            }
            // Set up pending request with timeout
            pendingRequests.set(id, {
                resolve: (payload) => sendResponse({ ok: true, payload }),
                reject: (err) => sendResponse({ ok: false, error: { message: String(err) } }),
            });
            // Timeout after 30 seconds
            setTimeout(() => {
                if (pendingRequests.has(id)) {
                    pendingRequests.delete(id);
                    sendResponse({ ok: false, error: { code: 'TIMEOUT', message: 'Request timed out' } });
                }
            }, 30000);
            return true; // Async response
        }
        case 'ping':
            sendToRelay({ type: 'ping' });
            sendResponse({ ok: true });
            return true;
        case 'get-connection-state':
            sendResponse({ state: connectionState });
            return true;
        case 'get-sessions': {
            // Request sessions list from Gateway
            const id = crypto.randomUUID();
            const frame = {
                type: 'req',
                id,
                method: 'sessions.list',
                params: {},
            };
            if (!sendToRelay(frame)) {
                sendResponse({ sessions: [] });
                return true;
            }
            pendingRequests.set(id, {
                resolve: (payload) => {
                    // Map Gateway session format to our StoredSession format
                    const gwSessions = (payload?.sessions || []);
                    const mappedSessions = gwSessions.map((s) => ({
                        id: s.key || crypto.randomUUID(),
                        title: s.displayName || 'Untitled',
                        createdAt: s.createdAt || Date.now(),
                        updatedAt: s.updatedAt || Date.now(),
                    }));
                    sendResponse({ sessions: mappedSessions });
                },
                reject: () => sendResponse({ sessions: [] }),
            });
            setTimeout(() => {
                if (pendingRequests.has(id)) {
                    pendingRequests.delete(id);
                    sendResponse({ sessions: [] });
                }
            }, 5000);
            return true;
        }
        case 'set-active-session':
            activeSessionId = message.sessionId;
            logger.info('Active session set', activeSessionId);
            // Subscribe to the session to receive events
            if (activeSessionId && ws && ws.readyState === WebSocket.OPEN) {
                const subId = crypto.randomUUID();
                ws.send(JSON.stringify({
                    type: 'req',
                    id: subId,
                    method: 'sessions.subscribe',
                    params: { sessionKey: activeSessionId },
                }));
                logger.info('Subscribed to session', activeSessionId);
            }
            sendResponse({ ok: true });
            return true;
        default:
            return false;
    }
});
// ============================================================================
// Startup
// ============================================================================
connect();
// Keep-alive: Chrome kills idle service workers after ~30 seconds
// of no activity. We don't have persistent background pages in MV3,
// so we use a simple heartbeat to keep the SW alive.
setInterval(() => {
    if (ws && ws.readyState === WebSocket.OPEN) {
        // Send a ping frame to keep connection alive
        ws.send(JSON.stringify({ type: 'ping' }));
    }
}, 25000);
logger.info('Service Worker started');
